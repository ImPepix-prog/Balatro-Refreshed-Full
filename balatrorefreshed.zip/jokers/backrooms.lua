
SMODS.Joker{ --Backrooms
    key = "backrooms",
    config = {
        extra = {
            odds = 10,
            odds2 = 10
        }
    },
    loc_txt = {
        ['name'] = 'Backrooms',
        ['text'] = {
            [1] = 'Played {C:attention}Face{} cards',
            [2] = 'have a {C:green}#1# in #2# {} Chance',
            [3] = 'of becoming {C:edition}Negative{} or being {C:red}{}{C:red}Destroyed{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["Refreshed_Refreshed_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_Refreshed_backrooms') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if context.other_card:is_face() then
                if SMODS.pseudorandom_probability(card, 'group_0_caec2ded', 1, card.ability.extra.odds, 'j_Refreshed_backrooms', false) then
                    local scored_card = context.other_card
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            
                            scored_card:set_edition("e_negative", true)
                            card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Upgrade!", colour = G.C.ORANGE})
                            return true
                        end
                    }))
                    
                end
            elseif context.other_card:is_face() then
                if SMODS.pseudorandom_probability(card, 'group_0_1300a8b5', 1, card.ability.extra.odds, 'j_Refreshed_backrooms', false) then
                    context.other_card.should_destroy = true
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
            end
        end
    end
}