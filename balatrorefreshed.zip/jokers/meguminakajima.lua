
SMODS.Joker{ --Megumi Nakajima
    key = "meguminakajima",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Megumi Nakajima',
        ['text'] = {
        [1] = 'No {C:attention}Effect{} yet ):'
    },
    ['unlock'] = {
        [1] = 'Unlocked by default.'
    }
},
pos = {
    x = 4,
    y = 5
},
display_size = {
    w = 71 * 1, 
    h = 95 * 1
},
cost = 20,
rarity = 4,
blueprint_compat = true,
eternal_compat = true,
perishable_compat = true,
unlocked = true,
discovered = true,
atlas = 'CustomJokers',
pools = { ["Refreshed_Refreshed_jokers"] = true },
soul_pos = {
    x = 5,
    y = 5
},
in_pool = function(self, args)
    return (
        not args 
        or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' 
        or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
    )
    and true
end
}