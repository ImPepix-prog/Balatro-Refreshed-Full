
SMODS.Joker{ --Teto Territory
    key = "tetoterritory",
    config = {
        extra = {
            chips0 = 31,
            mult0 = 15.5
        }
    },
    loc_txt = {
        ['name'] = 'Teto Territory',
        ['text'] = {
            [1] = 'If played hand contains a scoring',
            [2] = '{C:attention}Queen{} {C:blue}+31{} Chips and {C:red}+15.5{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["Refreshed_Refreshed_jokers"] = true, ["Refreshed_teto_joker"] = true, ["Refreshed_REALteto_joker"] = true, ["Refreshed_Vocaloid"] = true, ["Refreshed_RealVocaloid"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if playing_card:get_id() == Q then
                        count = count + 1
                    end
                end
                return count >= 1
            end)() then
                return {
                    chips = 31,
                    extra = {
                        mult = 15.5
                    }
                }
            end
        end
    end
}