
SMODS.Joker{ --Akage
    key = "akage",
    config = {
        extra = {
            xmult0 = 1.25,
            odds = 2,
            repetitions0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Akage',
        ['text'] = {
            [1] = 'Scored {C:hearts}Heart{} cards give {X:mult,C:white}X1.25{} Mult',
            [2] = 'and have a {C:green}#1# in #2# {}chance',
            [3] = 'of being {C:attention}Retriggered{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["Refreshed_Refreshed_jokers"] = true, ["Refreshed_teto_joker"] = true, ["Refreshed_REALteto_joker"] = true, ["Refreshed_Vocaloid"] = true, ["Refreshed_RealVocaloid"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_Refreshed_akage') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                return {
                    Xmult = 1.25
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_d49f52a2', 1, card.ability.extra.odds, 'j_Refreshed_akage', false) then
                            
                            return {repetitions = 1}
                        end
                        return true
                    end
                }
            end
        end
    end
}